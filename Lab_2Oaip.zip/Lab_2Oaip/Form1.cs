﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLib;


namespace Lab_2Oaip
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {

            InitializeComponent();

            Bitmap bitmap = new
            Bitmap(pictureBox1.ClientSize.Width,
            pictureBox1.ClientSize.Height);
            Pen pen = new Pen(Color.Black);
            Init.bitmap = bitmap;
            Init.pictureBox = pictureBox1;
            Init.pen = pen;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var rectagle = new
MyLib.Rectangle(
int.Parse(textBox1.Text),
int.Parse(textBox2.Text),
int.Parse(textBox3.Text), 
int.Parse(textBox4.Text));
            ShapeContainer.AddFigure(rectagle);
            rectagle.Draw();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var squar = new Square(
int.Parse(textBox8.Text),
int.Parse(textBox7.Text),
int.Parse(textBox6.Text));
            ShapeContainer.AddFigure(squar);
            squar.Draw();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var elip = new Ellipse(
int.Parse(textBox10.Text),
int.Parse(textBox9.Text),
int.Parse(textBox5.Text),
int.Parse(textBox11.Text));
            ShapeContainer.AddFigure(elip);
            elip.Draw();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var eli = new Circle(
int.Parse(textBox19.Text),
int.Parse(textBox18.Text),
int.Parse(textBox17.Text));
            ShapeContainer.AddFigure(eli);
            eli.Draw();
        }
    }
}