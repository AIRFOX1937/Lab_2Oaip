﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyLib
{
    public class Circle : Ellipse
    {

        public Circle(int x, int y, int w) : base(x, y, w, w)
        { }
        public override void Draw()
        {
            Graphics g = Graphics.FromImage(Init.bitmap);
            g.DrawEllipse(Init.pen, x, y, w, w);
            Init.pictureBox.Image = Init.bitmap;
        }
    }
}
